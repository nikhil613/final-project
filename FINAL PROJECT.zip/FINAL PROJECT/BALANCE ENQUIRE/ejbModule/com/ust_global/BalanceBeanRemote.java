package com.ust_global;
import java.util.List;

import javax.ejb.Remote;

@Remote
public interface BalanceBeanRemote {
	
	public List getChequeDetails();
	public boolean addAcNo(Balance b);
	public void addTransactionDetails(Balance b);
	public boolean depositDetails(int accno, double amt);
	public boolean withdrawDetails(int accno, double amt);

}

