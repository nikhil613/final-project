package com.ust_global;

import java.util.List;

import javax.ejb.Stateful;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Session Bean implementation class BalanceBean
 */
@Stateful
public class BalanceBean implements BalanceBeanRemote {
	@PersistenceContext(name="BalanceUnit")
	EntityManager entityManager;
    /**
     * Default constructor. 
     */
    public BalanceBean() {
        // TODO Auto-generated constructor stub
    }
	@Override
	public List getChequeDetails() {
		// TODO Auto-generated method stub
		List BalDetails=entityManager.createQuery("FROM BALINQ").getResultList();
		return BalDetails;
	}
	 public boolean addAcNo(Balance balance)
	    {
	    		boolean msg=false;
	    		
	    			try
	    			{
	    			
	    			
    				entityManager.merge(balance);
    				 msg=true;
    				 
    				
	    			}
	    			catch(Exception e)
	    			{
	    				msg=false;
	    			}
	    			 return msg;
	    	
	    	
	    }

}
