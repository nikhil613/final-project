package com.ust_global;

import javax.ejb.Stateful;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Session Bean implementation class CreditBean
 */
@Stateful
public class CreditBean implements CreditBeanRemote {
	@PersistenceContext(name="CreditUnit")
	EntityManager entityManager;
    /**
     * Default constructor. 
     */
    public CreditBean() {
        // TODO Auto-generated constructor stub
    }
    public void addCredit(Credit c)
    {
    	entityManager.persist(c);
    }
	@Override
	public boolean updateCredit(Credit c) {
		boolean msg = false;

		try {
			entityManager.merge(c);
			msg = true;

		} catch (Exception e) {
			msg = false;
		}
		return msg;

	}
}
