package com.ust_global;
import javax.ejb.Remote;

@Remote
public interface CreditBeanRemote {
	public void addCredit(Credit c);
	public boolean updateCredit(Credit c);
}
