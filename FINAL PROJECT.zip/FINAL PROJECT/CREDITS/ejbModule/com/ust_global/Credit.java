package com.ust_global;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity(name="CREDIT")
public class Credit implements Serializable {
	int sid;
	int accNo;
	int logCredit;
	int transCredit;
	int netCredit;
	
	public Credit() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Id
	@Column(name="SID")

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public int getLogCredit() {
		return logCredit;
	}

	public void setLogCredit(int logCredit) {
		this.logCredit = logCredit;
	}

	public int getTransCredit() {
		return transCredit;
	}

	public void setTransCredit(int transCredit) {
		this.transCredit = transCredit;
	}

	public int getNetCredit() {
		return netCredit;
	}

	public void setNetCredit(int netCredit) {
		this.netCredit = netCredit;
	}
	
	
	
	
	
}
