package com.ust_global;
import java.util.List;

import javax.ejb.Remote;

@Remote
public interface ChequeBeanRemote {
	public List getChequeDetails();
	public void addChequeDetails(Cheque c);
	public void deleteDetails(Cheque c);
	public boolean addDetails(int accNo,double amt);
}
