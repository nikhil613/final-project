package com.ust_global;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

import javax.ejb.Stateful;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Session Bean implementation class ChequeBean
 */
@Stateful
public class ChequeBean implements ChequeBeanRemote {
	@PersistenceContext(name="cheqUnit")
	EntityManager entityManager;
    /**
     * Default constructor. 
     */
    public ChequeBean() {
        // TODO Auto-generated constructor stub
    }
    public List getChequeDetails()
    {

	return null;
    	
    }
    
    public void addChequeDetails(Cheque c)
    {
    	entityManager.persist(c);
    }
    public void deleteDetails(Cheque c)
    {
    	entityManager.remove(c);
    }
    public boolean addDetails(int accNo,double amt)
    {


    		List allch=entityManager.createQuery("FROM BALINQ").getResultList();
    		boolean msg=false;
    		for(int i=0;i<allch.size();i++)
    		{
    			Cheque ch1=(Cheque)allch.get(i);
    			int get=ch1.getAccNo();
    			System.out.println(get);
    			if(accNo==get)
    			{
    				if(ch1.getAmount()!=0.0||ch1.getAmount()==0)
    				{
    				ch1.setAmount(amt);
    				double tbal=ch1.getBalance()+amt;
    				ch1.setBalance(tbal);
    				entityManager.merge(ch1);
    				 msg=true;
    				}
    			}
    			else
    			{
    				msg=false;
    			}
    		}
    	return msg;
    	
    }

}
