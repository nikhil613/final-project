package com.ust_global;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpSession;



public class Opening 
{
	String userName, userPassword, personName, personAddress;
	String accountNo;
	int duration;
	String loanDate, loanDueDate, loanType, roi;
	double loanAmount=0.0;
	int userID;
	int accNo;
	int accNo2;
	String accType;
	double Balance;
	double Amount;
	List balList=new ArrayList();
	List balList2=new ArrayList();
	
	
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public double getBalance() {
		return Balance;
	}
	public void setBalance(double balance) {
		Balance = balance;
	}
	public double getAmount() {
		return Amount;
	}
	public void setAmount(double amount) {
		Amount = amount;
	}
	public List getBalList() {
		return balList;
	}
	public void setBalList(List balList) {
		this.balList = balList;
	}
	List<PassWord> aboutMe=new ArrayList<PassWord>();
	
	public List<PassWord> getAboutMe() 
	{
		return aboutMe;
	}
	public void setAboutMe(List<PassWord> aboutMe) 
	{
		this.aboutMe = aboutMe;
	}
	public String getPersonAddress() 
	{
		return personAddress;
	}
	public void setPersonAddress(String personAddress) 
	{
		this.personAddress = personAddress;
	}
	public String getPersonName() 
	{
		return personName;
	}
	public void setPersonName(String personName) 
	{
		this.personName = personName;
	}
	
	
	public String getAccountNo() 
	{
		return accountNo;
	}
	public void setAccountNo(String accountNo) 
	{
		this.accountNo = accountNo;
	}
	public String getRoi() {
		return roi;
	}
	public void setRoi(String roi) 
	{
		this.roi = roi;
	}
	public int getDuration() 
	{
		return duration;
	}
	public void setDuration(int duration) 
	{
		this.duration = duration;
	}
	public String getLoanDate() 
	{
		return loanDate;
	}
	public void setLoanDate(String loanDate) 
	{
		this.loanDate = loanDate;
	}
	public String getLoanDueDate() 
	{
		return loanDueDate;
	}
	public void setLoanDueDate(String loanDueDate) 
	{
		this.loanDueDate = loanDueDate;
	}
	public double getLoanAmount() 
	{
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) 
	{
		this.loanAmount = loanAmount;
	}
	public String getLoanType() 
	{
		return loanType;
	}
	public void setLoanType(String loanType) 
	{
		this.loanType = loanType;
	}
	public List getBalList2() {
		return balList2;
	}
	public void setBalList2(List balList2) {
		this.balList2 = balList2;
	}
	
	public int getAccNo2() {
		return accNo2;
	}
	public void setAccNo2(int accNo2) {
		this.accNo2 = accNo2;
	}
	Properties prop;
	Context ctx;
	 
	public Opening() throws NamingException, ParseException 
	{
		prop=new Properties();
		prop.put(Context.PROVIDER_URL, "localhost:1099");
		prop.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		prop.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		ctx=new  InitialContext(prop);	
		
		
	}
	public String getUserName() 
	{
		return userName;
	}
	public void setUserName(String userName) 
	{
		this.userName = userName;
	}
	public String getUserPassword() 
	{
		return userPassword;
	}
	public void setUserPassword(String userPassword) 
	{
		this.userPassword = userPassword;
	}
	public String newUser()
	{
		String msg="";
		System.out.println("Hello");
		msg="new";
		return msg;
	}
	public String existingUser()
	{
		String msg="";
		System.out.println("Hellosd");
		msg="existing";
		return msg;
	}
	
	public String registration() throws NamingException //This method activates when a new user wants to create an account
	{
		System.out.println("Entering registration method");
		String msg="";
		ProductBeanRemote pbr1=(ProductBeanRemote)ctx.lookup("ProductBean/remote");
		
		FacesContext fc=FacesContext.getCurrentInstance();
		ExternalContext ec=fc.getExternalContext();
		HttpSession sess=(HttpSession) ec.getSession(false);
		String user=(String) sess.getAttribute("userName");
		Random random=new Random();
		
		int x=random.nextInt((90000-10000)+15500)+10000;
		int xx=random.nextInt((999-100)+1)+100;
		int val=random.nextInt((3-0)+1)+0;
		String acTypeList[]={"SAVINGS","CURRENT","RECURRING DEPOSIT","FIXED DEPOSIT"};
	
		BalanceBeanRemote balbr=(BalanceBeanRemote)ctx.lookup("BalanceBean/remote");

		Balance balance=new Balance();
		try
		{
			
			System.out.println("In try");
			PassWord DetailsAdd=new PassWord();
		
			
			DetailsAdd.setUserName(this.userName);
		
			DetailsAdd.setUserPassword(this.userPassword);
			DetailsAdd.setPersonName(this.personName);
			DetailsAdd.setPersonAddress(this.personAddress);
			
			balance.setUserID(xx);
			balance.setUsername(this.userName);
			balance.setBalance(x);
			balance.setAccType(acTypeList[val]);
			balance.setAccNo(this.accNo);
			
			balbr.addAcNo(balance);;
			pbr1.addUser(DetailsAdd);

//			FacesContext fc1=FacesContext.getCurrentInstance();
//			ExternalContext ec1=fc1.getExternalContext();
//			HttpSession session1=(HttpSession) ec1.getSession(false);
//			session1.setAttribute("userName", this.userName);
//			msg="home";
		}
		catch(Exception e)
		{
			System.out.println("Duplicate Sales id Detected");
		}
		System.out.println("before returning from registration "+msg);
		return msg;
	}
	public String login() throws NamingException //This method activates when an existing user wishes to login
	{	
		String msg="";
		ProductBeanRemote pbr1=(ProductBeanRemote)ctx.lookup("ProductBean/remote");
		List<PassWord> readAllDetails=pbr1.readAll();
		for (int i = 0; i < readAllDetails.size(); i++) 
		{
			PassWord pw=readAllDetails.get(i);
			if(pw.getUserName().equals(this.userName) && pw.getUserPassword().equals(this.userPassword))
			{
				
				FacesContext fc=FacesContext.getCurrentInstance();
				ExternalContext ec=fc.getExternalContext();
				HttpSession session=(HttpSession) ec.getSession(false);
				session.setAttribute("userName", this.userName);
				msg= "Success";
				break;
			}
			else
			{
				msg= "Failure";
			}
			
		}
		return msg;
	}
	public String logout() //This method activates when the user wishes to logout
	{
		String logoutMsg="";		
		FacesContext fc=FacesContext.getCurrentInstance();
		ExternalContext ec=fc.getExternalContext();
		HttpSession sess=(HttpSession) ec.getSession(false);
		
		if(sess!=null)
		{
			String x=(String) sess.getAttribute("userName");
			if(x!=null)
			{
				System.out.println("We are going to logout");
				sess.removeAttribute("userName");
				sess.invalidate();
				logoutMsg="LoggedOut";
			}
		}
		return logoutMsg;
	}
	public String loanChecker()
	{
		String msg="d";
		return msg;
	}
	public String loanDatabaseWriter() throws NamingException, ParseException
	{
		Loan loan=new Loan();
		LoanBeanRemote lbr=(LoanBeanRemote) ctx.lookup("LoanBean/remote");
		Calendar calendar=Calendar.getInstance();
		 SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
	     String stringDate=dateFormat.format(new Date());
	     Date date=dateFormat.parse(stringDate);
	     
		loan.setAccountNo(accountNo);
		if(this.loanType.equalsIgnoreCase("1"))
		{
			loan.setLoanType("Personal Loan");
			loan.setRoi("8.5");
		}
		else if(this.loanType.equalsIgnoreCase("2"))
		{
			loan.setLoanType("Automobile Loan");
			loan.setRoi("12");
		}
		else if(this.loanType.equalsIgnoreCase("3"))
		{
			loan.setLoanType("Education Loan");
			loan.setRoi("20.5");
		}
		loan.setDuration(duration);
		loan.setLoanDate(stringDate);
		calendar.add(Calendar.MONTH, (duration));
		String strDate=dateFormat.format(calendar.getTime());
		System.out.println(strDate);
		loan.setLoanDueDate(strDate);
		loan.setLoanAmount(loanAmount);
		lbr.addLoanDetails(loan);
		
		return "Sanctioned";
		
	}
	
	public String myInformation() throws NamingException
	{
		System.out.println("I am in myInformation method");
		String msg="";
		ProductBeanRemote pbr1=(ProductBeanRemote)ctx.lookup("ProductBean/remote");
		
		FacesContext fc=FacesContext.getCurrentInstance();
		ExternalContext ec=fc.getExternalContext();
		HttpSession sess=(HttpSession) ec.getSession(false);
		String user=(String) sess.getAttribute("userName");
		
		BalanceBeanRemote balbr=(BalanceBeanRemote)ctx.lookup("BalanceBean/remote");
		balList=balbr.getChequeDetails();

		 aboutMe=pbr1.readAll();
			for(int i=0;i<balList.size();i++)
			{
				Balance bal=(Balance)balList.get(i);
				if(user.equalsIgnoreCase(bal.getUsername()))
				{
					balList2.add(bal);
					accNo2=bal.getAccNo();
				}
			}
		   if(!aboutMe.isEmpty())
			   
		    msg="result";
		   else
		    msg="fail";
		   return msg;
	}
	public String showBalance() throws NamingException
	{
		FacesContext fc=FacesContext.getCurrentInstance();
		ExternalContext ec=fc.getExternalContext();
		HttpSession sess=(HttpSession) ec.getSession(false);
		String user=(String) sess.getAttribute("userName");
		BalanceBeanRemote balbr=(BalanceBeanRemote)ctx.lookup("BalanceBean/remote");
		balList2=balbr.getChequeDetails();
		balList.removeAll(balList);
		try
		{
		for(int i=0;i<balList2.size();i++)
		{
			Balance bal=(Balance)balList2.get(i);
			if(user.equalsIgnoreCase(bal.getUsername()))
			{
				balList.add(bal);
				
			}
		}
		
		return "balance";
		}
		catch(Exception e)
		{
			return "bfailed";
		}
}
	

}
