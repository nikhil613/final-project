package com.ust_global;

import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class Transactionss {
	
	private int userId;
	private int accNo;
	private double balance;
	private double amount;
	String msg="";
	String option;
	String input;
	
	Transaction transactionDetailsByAccNo=new Transaction();
	
	Properties prop;
	Context ctx;
	public Transactionss() throws NamingException {
		prop=new Properties();
		prop.put(Context.PROVIDER_URL, "localhost:1099");
		prop.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		prop.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		ctx=new  InitialContext(prop);	
	
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getOption() {
		return option;
	}

	public void setOption(String option) {
		this.option = option;
	}

	public String getInput() {
		return input;
	}

	public void setInput(String input) {
		this.input = input;
	}

	public Transaction getTransactionDetailsByAccNo() {
		return transactionDetailsByAccNo;
	}

	public void setTransactionDetailsByAccNo(Transaction transactionDetailsByAccNo) {
		this.transactionDetailsByAccNo = transactionDetailsByAccNo;
	}
	
	public String depositDetails() throws NamingException {

		TransactionBeanRemote transRemote=(TransactionBeanRemote) ctx.lookup("TransactionBean/remote");
		this.msg="";
		if(transRemote!=null)
		{
			transRemote.depositDetails(this.accNo, this.amount);
			msg=this.amount+" has been deposited";
			return "Deposit";
		}
		else
		{
			msg="Deposit of the amount had failed";
			return "dfailed";
		}
		
	}
	
	public String withdrawDetails() throws NamingException{

		TransactionBeanRemote transRemote=(TransactionBeanRemote) ctx.lookup("TransactionBean/remote");
		this.msg=null;
		if(transRemote!=null)
		{
			transRemote.withdrawDetails(this.accNo, this.amount);
			msg=amount+" has been drawn";
			return "withdraw";
		}
		else
		{
			msg="Withdrawal has failed";
		}
		this.msg=null;
		return "wfailed";
	}
	
	public String TransactionDetails() throws NamingException
	{
		TransactionBeanRemote transRemote=(TransactionBeanRemote) ctx.lookup("TransactionBean/remote");
		
		
		transactionDetailsByAccNo=(Transaction) transRemote.transactionDetails(accNo);
		if(!transactionDetailsByAccNo.equals(null))
		{
			msg="Transaction";
		}
		else
		{
			msg="tfailed";
		}
		return msg;
	}
}
	