package com.ust_global;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class BalnceEnq {
	int userID;
	int accNo;
	String accType;
	double Balance;
	double Amount;
	List balList=new ArrayList();
	
	public BalnceEnq() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getUserID() {
		return userID;
	} 
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public double getBalance() {
		return Balance;
	}
	public void setBalance(double balance) {
		Balance = balance;
	}
	public double getAmount() {
		return Amount;
	}
	public void setAmount(double amount) {
		Amount = amount;
	}
	public List getBalList() {
		return balList;
	}
	public void setBalList(List balList) {
		this.balList = balList;
	}
	
	public String showBalance() throws NamingException
	{
		Properties p = new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,
				"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx = new InitialContext(p);
		
		BalanceBeanRemote balbr=(BalanceBeanRemote)ctx.lookup("BalanceBean/remote");
		try
		{
		balList=balbr.getChequeDetails();
		return "success";
		}
		catch(Exception e)
		{
			return "failed";
		}
	

		
		
	}
	
}
