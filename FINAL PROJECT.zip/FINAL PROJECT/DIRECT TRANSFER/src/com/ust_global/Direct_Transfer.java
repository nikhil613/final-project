package com.ust_global;
public class Direct_Transfer {
	int ID;
	int accNo;
	double Amount;
	public Direct_Transfer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public double getAmount() {
		return Amount;
	}
	public void setAmount(double amount) {
		Amount = amount;
	}
	
	public String transferProcess()
	{
		return null;
	}
}
